import React from 'react';
import { LinkItem } from '../types';

interface LinkCardProps {
  item: LinkItem;
  index: number;
}

const LinkCard: React.FC<LinkCardProps> = ({ item, index }) => {
  // Use index to stagger animation delay
  const style = {
    animationDelay: `${index * 100}ms`
  };

  return (
    <a
      href={item.url}
      target="_blank"
      rel="noopener noreferrer"
      style={style}
      className="flex items-center p-3 sm:p-4 bg-teal-800/80 backdrop-blur-sm border border-teal-700/50 rounded-2xl w-full shadow-lg hover:bg-teal-700 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] animate-slide-up opacity-0"
    >
      <div className="flex-shrink-0 w-10 h-10 sm:w-11 sm:h-11 bg-teal-600/30 rounded-full flex items-center justify-center border border-teal-500/20">
        {item.icon}
      </div>
      
      <span className="flex-grow text-center text-base sm:text-lg font-medium text-white px-2">
        {item.title}
      </span>
      
      {/* Spacer to keep text centered visually by balancing the icon width */}
      <div className="w-10 sm:w-11 flex-shrink-0"></div>
    </a>
  );
};

export default LinkCard;