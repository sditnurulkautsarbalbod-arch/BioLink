import React from 'react';
import { LinkItem, SocialLink } from './types';

export const SCHOOL_NAME = "SD IT Nurul Kautsar";

// Reusable SVG Paths
const DocumentIcon = (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-white">
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
  </svg>
);

export const LINKS: LinkItem[] = [
  {
    id: 'journal',
    title: "Jurnal dan Absen",
    url: "https://jurnalnk.vercel.app//",
    icon: DocumentIcon
  },
  {
    id: 'cbt-4',
    title: "Ujian Kelas 4",
    url: "https://sditnurulkautsarbalbod-arch.github.io/CBT-KLS4/",
    icon: DocumentIcon
  },
  {
    id: 'cbt-5',
    title: "Ujian Kelas 5",
    url: "https://sditnurulkautsarbalbod-arch.github.io/CBT-KLS5/",
    icon: DocumentIcon
  },
  {
    id: 'cbt-6',
    title: "Ujian Kelas 6",
    url: "https://sditnurulkautsarbalbod-arch.github.io/CBT-KLS6/",
    icon: DocumentIcon
  },
  {
    id: 'calendar',
    title: "Kalender Pendidikan",
    url: "https://sditnurulkautsarbalbod-arch.github.io/Kaldik/",
    icon: DocumentIcon
  },
  {
    id: 'inventory',
    title: "Inventaris & Buku",
    url: "https://sditnurulkautsarbalbod-arch.github.io/Inventaris/",
    icon: DocumentIcon
  },
  {
    id: 'modules',
    title: "Modul Ajar",
    url: "https://modulajarnk.vercel.app/",
    icon: DocumentIcon
  }
];

export const SOCIAL_LINKS: SocialLink[] = [
  {
    platform: 'Facebook',
    url: "https://www.facebook.com/profile.php?id=100074236762617",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7">
        <path d="M9.198 21.5h4v-8.01h2.669l.399-3.101h-3.068v-1.979c0-.899.251-1.512 1.533-1.512h1.634V3.887c-.283-.038-1.255-.122-2.388-.122-2.36 0-3.975 1.442-3.975 4.092v2.299H7v3.101h2.198V21.5z" />
      </svg>
    )
  },
  {
    platform: 'Instagram',
    url: "https://www.instagram.com/sditnurulkautsarmakassar/",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7">
        <path d="M12 2c-2.717 0-3.056.01-4.122.06-1.065.05-1.79.217-2.428.465a4.902 4.902 0 00-1.772 1.153 4.902 4.902 0 00-1.153 1.772c-.247.637-.415 1.363-.465 2.428C2.013 8.944 2 9.283 2 12s.013 3.056.06 4.122c.05 1.065.217 1.79.465 2.428a4.902 4.902 0 001.153 1.772 4.902 4.902 0 001.772 1.153c.637.247 1.363.415 2.428.465C8.944 21.987 9.283 22 12 22s3.056-.013 4.122-.06c1.065-.05 1.79-.217 2.428-.465a4.902 4.902 0 001.772-1.153 4.902 4.902 0 001.153-1.772c.247-.637.415-1.363.465-2.428C21.987 15.056 22 14.717 22 12s-.013-3.056-.06-4.122c-.05-1.065-.217-1.79-.465-2.428a4.902 4.902 0 00-1.153-1.772 4.902 4.902 0 00-1.772-1.153c-.637-.247-1.363-.415-2.428-.465C15.056 2.013 14.717 2 12 2zm0 1.802c2.67 0 2.987.01 4.042.059.975.044 1.504.207 1.857.344.467.182.8.398 1.15.748.35.35.566.683.748 1.15.137.353.3.882.344 1.857.05 1.055.058 1.372.058 4.042s-.009 2.987-.058 4.042c-.044.975-.207 1.504-.344 1.857a3.097 3.097 0 01-.748 1.15 3.097 3.097 0 01-1.15.748c-.353.137-.882.3-1.857.344-1.055.05-1.372.058-4.042.058s-2.987-.009-4.042-.058c-.975-.044-1.504-.207-1.857-.344a3.097 3.097 0 01-1.15-.748 3.097 3.097 0 01-.748-1.15c-.137-.353-.3-.882-.344-1.857C4.01 15.056 4 14.717 4 12s.009-2.987.058-4.042c.044-.975.207-1.504.344-1.857.182-.467.398-.8.748-1.15.35-.35.683-.566 1.15-.748.353-.137.882-.3 1.857-.344C9.013 3.81 9.33 3.802 12 3.802zM12 7.177a4.823 4.823 0 100 9.646 4.823 4.823 0 000-9.646zm0 1.802a3.02 3.02 0 110 6.04 3.02 3.02 0 010-6.04zM17.53 6.13a1.44 1.44 0 100 2.88 1.44 1.44 0 000-2.88z" />
      </svg>
    )
  }
];